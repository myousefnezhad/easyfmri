"""
This file used for testing search occurences and the likes.

Do not modify it or some tests will fail.

"""
import os
import sys


class Foo:
    class FooInner:
        def spam(self):
            pass

    def eggs(self):
        pass


def eggs():
    pass


def spam():
    pass
