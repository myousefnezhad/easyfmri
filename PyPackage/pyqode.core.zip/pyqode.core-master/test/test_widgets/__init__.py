"""
Those tests are very basic, we just check if the widget can be instantiated
without error (to make sure they work for the supported environmne
"""
