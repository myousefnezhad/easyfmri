pyqode.core.panels package
==========================

.. toctree::
   :maxdepth: 4

Module content
--------------

.. automodule:: pyqode.core.panels


Classes
-------

CheckerPanel
++++++++++++

.. autoclass:: pyqode.core.panels.CheckerPanel
    :members:
    :undoc-members:
    :show-inheritance:

EncodingPanel
+++++++++++++

.. autoclass:: pyqode.core.panels.EncodingPanel
    :members:
    :undoc-members:
    :show-inheritance:

FoldingPanel
++++++++++++

.. autoclass:: pyqode.core.panels.FoldingPanel
    :members:
    :undoc-members:
    :show-inheritance:

LineNumberPanel
+++++++++++++++

.. autoclass:: pyqode.core.panels.LineNumberPanel
    :members:
    :undoc-members:
    :show-inheritance:

Marker
++++++

.. autoclass:: pyqode.core.panels.Marker
    :members:
    :undoc-members:
    :show-inheritance:

MarkerPanel
+++++++++++

.. autoclass:: pyqode.core.panels.MarkerPanel
    :members:
    :undoc-members:
    :show-inheritance:

SearchAndReplacePanel
+++++++++++++++++++++

.. autoclass:: pyqode.core.panels.SearchAndReplacePanel
    :members:
    :undoc-members:
    :show-inheritance:

GlobalCheckerPanel
++++++++++++++++++

.. autoclass:: pyqode.core.panels.GlobalCheckerPanel
    :members:
    :undoc-members:
    :show-inheritance:
