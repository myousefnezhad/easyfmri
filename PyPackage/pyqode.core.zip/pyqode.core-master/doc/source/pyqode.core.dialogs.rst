pyqode.core.dialogs package
===========================

.. toctree::
   :maxdepth: 4

Module content
--------------

.. automodule:: pyqode.core.dialogs


Classes
-------

DlgPreferredEncodingsEditor
+++++++++++++++++++++++++++

.. autoclass:: pyqode.core.dialogs.DlgPreferredEncodingsEditor
    :members:
    :undoc-members:
    :show-inheritance:

DlgGotoLine
+++++++++++

.. autoclass:: pyqode.core.dialogs.DlgGotoLine
    :members:
    :undoc-members:
    :show-inheritance:

DlgUnsavedFiles
+++++++++++++++

.. autoclass:: pyqode.core.dialogs.DlgUnsavedFiles
    :members:
    :undoc-members:
    :show-inheritance:
