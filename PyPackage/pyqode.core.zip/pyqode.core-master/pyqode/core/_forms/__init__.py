# -*- coding: utf-8 -*-
"""
This package contains the scripts for the froms designed in Qt Designer

To update this folder, install ``pyqt_distutils`` and ``pyqode-uic``
(using pip) and run::

    python setup.py build_ui

"""
