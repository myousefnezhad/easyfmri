#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
logging.basicConfig(level=logging.INFO)
from notepad import main

if __name__ == '__main__':
    main()
