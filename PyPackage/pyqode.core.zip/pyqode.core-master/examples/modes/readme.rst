This directory contains minimal examples demonstrating the use of a single
mode.
