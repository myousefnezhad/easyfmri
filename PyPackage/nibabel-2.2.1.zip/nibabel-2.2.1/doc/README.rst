#####################
Nibabel documentation
#####################

To build the documentation, change to the root directory (containing
``setup.py``) and run::

    pip install -r doc-requirements.txt
    make html
