.. _manual:

**************
NiBabel Manual
**************

.. toctree::

  installation
  gettingstarted
  nibabel_images
  images_and_memory
  nifti_images
  image_orientation
  legal
  changelog
