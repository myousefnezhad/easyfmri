# init for sext package
""" Setuptools extensions

nibabel uses these routines, and houses them, and installs them.  nipy-proper
and dipy use them.
"""

