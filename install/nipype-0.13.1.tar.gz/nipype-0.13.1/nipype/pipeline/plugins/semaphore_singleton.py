# -*- coding: utf-8 -*-
from __future__ import print_function, division, unicode_literals, absolute_import
import threading
semaphore = threading.Semaphore(0)
