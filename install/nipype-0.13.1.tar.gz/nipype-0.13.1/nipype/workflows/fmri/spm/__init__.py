# -*- coding: utf-8 -*-
from .preprocess import (create_spm_preproc, create_vbm_preproc,
                         create_DARTEL_template)
