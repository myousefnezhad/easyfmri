# -*- coding: utf-8 -*-
from __future__ import absolute_import

from nipype.utils.config import NUMPY_MMAP
from nipype.utils.onetime import OneTimeProperty, setattr_on_read
from nipype.utils.tmpdirs import TemporaryDirectory, InTemporaryDirectory
