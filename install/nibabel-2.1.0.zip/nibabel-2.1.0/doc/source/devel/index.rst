.. -*- mode: rst -*-
.. ex: set sts=4 ts=4 sw=4 et tw=79:

.. _devindex:

Developer documentation page
============================

.. toctree::
    :maxdepth: 2

    devguide
    add_test_data
    add_image_format
    devdiscuss
    make_release
    advanced_testing
