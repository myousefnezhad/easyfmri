# -*- coding: utf-8 -*-
"""This directory is meant for IPython extensions."""
